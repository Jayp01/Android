package com.example.dell.mycalci;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

public class Homepage extends AppCompatActivity {
    Button start;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_homepage);

    }
    public void buttonclickact(View v) {
        start=(Button)findViewById(R.id.button2);
        Intent i=new Intent(this,CalciActivity.class);
        startActivity(i);
    }


}
