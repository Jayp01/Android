package com.example.dell.mycalci;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CalciActivity extends AppCompatActivity {
    Button b1,b2,b3,b4,b5,b6,b7,b8,b9,bZero,bAdd,bSub,bMult,bDiv,bEqual,bClear,bCE,exit;
    TextView input,result;
    String s="",s1="",s2="",resultstr="";
    int i=0,i1=-1,c=-1;
    int res=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        bZero=(Button)findViewById(R.id.zero);
        b1=(Button)findViewById(R.id.one);
        b2=(Button)findViewById(R.id.two);
        b3=(Button)findViewById(R.id.three);
        b4=(Button)findViewById(R.id.four);
        b5=(Button)findViewById(R.id.five);
        b6=(Button)findViewById(R.id.six);
        b7=(Button)findViewById(R.id.seven);
        b8=(Button)findViewById(R.id.eight);
        b9=(Button)findViewById(R.id.nine);
        bAdd=(Button)findViewById(R.id.add);
        bSub=(Button)findViewById(R.id.sub);
        bMult=(Button)findViewById(R.id.mult);
        bDiv=(Button)findViewById(R.id.div);
        bCE=(Button)findViewById(R.id.reset);
        bClear=(Button)findViewById(R.id.clear);
        bEqual=(Button)findViewById(R.id.equals);
        input=(TextView)findViewById(R.id.InputText);
        result=(TextView)findViewById(R.id.ResultText);
        bZero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s=(String)result.getText();
                if(s.equals("+")||s.equals("-")||s.equals("*")||s.equals("/"))
                {
                    result.setText("");
                    s="";
                }
                result.setText(s+"0");
                s="";
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s=(String)result.getText();
                if(s.equals("+")||s.equals("-")||s.equals("*")||s.equals("/"))
                {
                    result.setText("");
                    s="";
                }
                result.setText(s+"1");
                s="";
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s=(String)result.getText();
                if(s.equals("+")||s.equals("-")||s.equals("*")||s.equals("/"))
                {
                    result.setText("");
                    s="";
                }
                result.setText(s+"2");
                s="";
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s=(String)result.getText();
                if(s.equals("+")||s.equals("-")||s.equals("*")||s.equals("/"))
                {
                    result.setText("");
                    s="";
                }
                result.setText(s+"3");
                s="";
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s=(String)result.getText();
                if(s.equals("+")||s.equals("-")||s.equals("*")||s.equals("/"))
                {
                    result.setText("");
                    s="";
                }
                result.setText(s+"4");
                s="";
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s=(String)result.getText();
                if(s.equals("+")||s.equals("-")||s.equals("*")||s.equals("/"))
                {
                    result.setText("");
                    s="";
                }
                result.setText(s+"5");
                s="";
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s=(String)result.getText();
                if(s.equals("+")||s.equals("-")||s.equals("*")||s.equals("/"))
                {
                    result.setText("");
                    s="";
                }
                result.setText(s+"6");
                s="";
            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s=(String)result.getText();
                if(s.equals("+")||s.equals("-")||s.equals("*")||s.equals("/"))
                {
                    result.setText("");
                    s="";
                }
                result.setText(s+"7");
                s="";
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s=(String)result.getText();
                if(s.equals("+")||s.equals("-")||s.equals("*")||s.equals("/"))
                {
                    result.setText("");
                    s="";
                }
                result.setText(s+"8");
                s="";
            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s=(String)result.getText();
                if(s.equals("+")||s.equals("-")||s.equals("*")||s.equals("/"))
                {
                    result.setText("");
                    s="";
                }
                result.setText(s+"9");
                s="";
            }
        });
    bAdd.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            String tmp=(String) result.getText();
            if(tmp.isEmpty())
            {
                s1="0";
            }
            else if(!tmp.equals("+")&&!tmp.equals("-")&&!tmp.equals("*")&&!tmp.equals("/"))
            {
                s1=tmp;
            }
            c=0;
            resultstr="";
            result.setText("+");
            input.setText(s1+"+");
        }
    });
        bSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tmp=(String) result.getText();
                if(tmp.isEmpty())
                {
                    s1="0";
                }
                else if(!tmp.equals("+")&&!tmp.equals("-")&&!tmp.equals("*")&&!tmp.equals("/"))
                {
                    s1=tmp;
                }
                c=1;
                resultstr="";
                result.setText("-");
                input.setText(s1+"-");
            }
        });

        bDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tmp=(String) result.getText();
                if(tmp.isEmpty())
                {
                    s1="0";
                }
                else if(!tmp.equals("+")&&!tmp.equals("-")&&!tmp.equals("*")&&!tmp.equals("/"))
                {
                    s1=tmp;
                }
                c=2;
                resultstr="";
                result.setText("/");
                input.setText(s1+"/");
            }
        });

        bMult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tmp=(String) result.getText();
                if(tmp.isEmpty())
                {
                    s1="0";
                }
                else if(!tmp.equals("+")&&!tmp.equals("-")&&!tmp.equals("*")&&!tmp.equals("/"))
                {
                    s1=tmp;
                }
                c=3;
                resultstr="";
                result.setText("*");
                input.setText(s1+"*");
            }
        });
        bEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String op = "";
                if (s1.equalsIgnoreCase("+") || s1.equalsIgnoreCase("-") || s1.equalsIgnoreCase("/") || s1.equalsIgnoreCase("*")) {
                    i = 0;
                } else if (s1 == null || s1.isEmpty())
                    i = 0;
                else
                    i = Integer.parseInt(s1);
                if (resultstr.isEmpty()) {
                    s2 = (String) result.getText();
                    if (s2.equalsIgnoreCase("+") || s2.equalsIgnoreCase("-") || s2.equalsIgnoreCase("/") || s2.equalsIgnoreCase("*")) {
                        i1 = 0;
                    } else if (s2 == null || s2.isEmpty())
                        i1 = 0;
                    else
                        i1 = Integer.parseInt(s2);
                } else
                    i = res;
                if (c == 0) {
                    op = "+";
                    res = i + i1;
                } else if (c == 1) {
                    op = "-";
                    res = i - i1;
                } else if (c == 2) {
                    op = "/";
                    if (i1 == 0) {
                        Toast.makeText(getApplicationContext(), "Invalid Input", Toast.LENGTH_LONG).show();
                        res = 0;
                    } else
                        res = i / i1;
                } else if (c == 3) {
                    op = "*";
                    res = i * i1;
                } else {
                    op = "";
                    res = 0;
                }
                if (!op.isEmpty()) {
                    input.setText(i + "" + op + "" + i1);
                } else
                    input.setText("");
                resultstr = String.valueOf(res);
                result.setText(resultstr);
            }
        });

    bClear.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            s=(String)result.getText();
            if(s.equals("+")||s.equals("-")||s.equals("/")||s.equals("*"))
            {
                i=0;
            }
            else
            {
                i=Integer.parseInt(s);
                i=i/10;
            }
            if(i==0)
            {
                result.setText("");
            }
            else
                result.setText(i+"");
            s=null;
        }
    });
        bCE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                result.setText("");
                input.setText("");
                i=0;
                i1=0;
                s1="";
                s2="";
                resultstr="";
                c=-1;
                res=0;
            }
        });
}
public void onexitclick(View v){
    exit=(Button)findViewById(R.id.button);
    Intent i1=new Intent(this,Homepage.class);
    startActivity(i1);
}
}