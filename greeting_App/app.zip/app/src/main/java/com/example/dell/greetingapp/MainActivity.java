package com.example.dell.greetingapp;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b ;
    EditText editName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editName=(EditText)findViewById(R.id.Text);
        b =(Button)findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name= (editName).getText().toString();
                if(name.equals("") || (name.trim().length()==0))
                {
                    Toast.makeText(getApplicationContext(),"Please enter your name",Toast.LENGTH_LONG).show();
                }
                else
                {
                    try{
                        Bundle bundle=new Bundle();
                        bundle.putString("name",name);
                        String pack= getPackageName()+".Main2Activity";
                        Class cls=Class.forName(pack);
                        Intent i=new Intent(MainActivity.this,cls);
                        i.putExtras(bundle);
                        startActivity(i);
                    }
                    catch(ClassNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        }
        );
    }
}
