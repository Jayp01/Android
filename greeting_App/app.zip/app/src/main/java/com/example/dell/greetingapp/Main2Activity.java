package com.example.dell.greetingapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent i = getIntent();
        Bundle extras = i.getExtras();
        String name = extras.getString("name");
        String msg = "Hello " + name +"!"+" Welcome to Android...";
        TextView welcomeMsg = (TextView) findViewById(R.id.textView);
        welcomeMsg.setText(msg);
        RatingBar bar=(RatingBar)findViewById(R.id.ratingBar);
        bar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                Toast.makeText(Main2Activity.this, "Rating is "+ v, Toast.LENGTH_SHORT).show();
                Toast.makeText(Main2Activity.this,"Thank you",Toast.LENGTH_SHORT);
            }
        });

    }
}
